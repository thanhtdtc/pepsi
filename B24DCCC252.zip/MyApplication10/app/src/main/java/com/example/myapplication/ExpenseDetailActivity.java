package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ExpenseDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_detail);

        Expense e = (Expense) getIntent().getSerializableExtra("expense");
        int position = getIntent().getIntExtra("position", -1);

        TextView tvName = findViewById(R.id.tvDetailName);
        TextView tvAmount = findViewById(R.id.tvDetailAmount);
        TextView tvCategory = findViewById(R.id.tvDetailCategory);
        TextView tvDate = findViewById(R.id.tvDetailDate);
        TextView tvNote = findViewById(R.id.tvDetailNote);
        Button btnBack = findViewById(R.id.btnBack);
        Button btnDelete = findViewById(R.id.btnDelete);

        if (e != null) {
            tvName.setText(e.getName());
            tvAmount.setText(ExpenseAdapter.formatMoney(e.getAmount()));
            tvCategory.setText(e.getCategory());
            tvDate.setText(e.getDate());
            tvNote.setText(e.getNote().isEmpty() ? "(không có)" : e.getNote());
        }

        findViewById(R.id.btnHeaderBack).setOnClickListener(v -> finish());
        btnBack.setOnClickListener(v -> finish());

        btnDelete.setOnClickListener(v -> {
            Intent data = new Intent();
            data.putExtra("delete_position", position);
            setResult(RESULT_OK, data);
            finish();
        });
    }
}