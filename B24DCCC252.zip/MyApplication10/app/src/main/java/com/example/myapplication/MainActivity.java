package com.example.myapplication;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private final ArrayList<Expense> expenses = new ArrayList<>();
    private ExpenseAdapter adapter;
    private TextView tvTotal;

    // Nhận kết quả từ màn hình Thêm khoản chi
    private final ActivityResultLauncher<Intent> addLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Expense e = (Expense) result.getData().getSerializableExtra("expense");
                    if (e != null) {
                        expenses.add(e);
                        refresh();
                    }
                }
            });

    // Nhận kết quả từ màn hình Chi tiết (xóa)
    private final ActivityResultLauncher<Intent> detailLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    int pos = result.getData().getIntExtra("delete_position", -1);
                    if (pos >= 0 && pos < expenses.size()) {
                        expenses.remove(pos);
                        refresh();
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvTotal = findViewById(R.id.tvTotal);
        ListView lvExpenses = findViewById(R.id.lvExpenses);
        Button btnAdd = findViewById(R.id.btnAdd);

        // Dữ liệu mẫu
        String today = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        expenses.add(new Expense("Ăn sáng", 30000, "Ăn uống", today, ""));
        expenses.add(new Expense("Đổ xăng", 50000, "Đi lại", today, ""));
        expenses.add(new Expense("Mua sách", 120000, "Học tập", today, ""));

        adapter = new ExpenseAdapter(this, expenses);
        lvExpenses.setAdapter(adapter);
        updateTotal();

        btnAdd.setOnClickListener(v ->
                addLauncher.launch(new Intent(this, AddExpenseActivity.class)));

        lvExpenses.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(this, ExpenseDetailActivity.class);
            intent.putExtra("expense", expenses.get(position));
            intent.putExtra("position", position);
            detailLauncher.launch(intent);
        });
    }

    private void refresh() {
        adapter.notifyDataSetChanged();
        updateTotal();
    }

    private void updateTotal() {
        long total = 0;
        for (Expense e : expenses) total += e.getAmount();
        tvTotal.setText(ExpenseAdapter.formatMoney(total));    }
}